#include "player.h" //<string>

Player::Player() { //constructor definition outside a class
    
        runsScored = 0;
        ballsPlayed = 0;
        ballsBowled = 0;
        runsGiven = 0;
        wicketsTaken = 0;
    
}