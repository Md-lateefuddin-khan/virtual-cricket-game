#include "team.h" // "player.h" <vector> <string>


Team::Team() {
    totalRunsScored = 0;
    wicketsLost = 0;
    totalBallsBowled = 0;
}