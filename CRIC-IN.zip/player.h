#include <string>

class Player {
    
    public:
        Player(); //Default Constructor Decleration
        std :: string name; //namespace std is not a good practice in header files
        int id;
        int runsScored;
        int ballsPlayed;
        int ballsBowled;
        int runsGiven;
        int wicketsTaken;
    
    
};